from flask import Flask
from flask import request
import pymysql
import requests
import cv2
import numpy as np
import mediapipe as mp
import threading
import pyttsx3
import json

app = Flask(__name__)

app.secret_key = 'any random string'

url = "http://192.168.0.101:8080/shot.jpg"

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="fitness")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

"----------------------------------------   BICEPS   ---------------------------------------------------------"

def calc_angle(a,b,c): # 3D points
    ''' Arguments:
        a,b,c -- Values (x,y,z, visibility) of the three points a, b and c which will be used to calculate the
                vectors ab and bc where 'b' will be 'elbow', 'a' will be shoulder and 'c' will be wrist.
        
        Returns:
        theta : Angle in degress between the lines joined by coordinates (a,b) and (b,c)
    '''
    a = np.array([a.x, a.y])#, a.z])    # Reduce 3D point to 2D
    b = np.array([b.x, b.y])#, b.z])    # Reduce 3D point to 2D
    c = np.array([c.x, c.y])#, c.z])    # Reduce 3D point to 2D

    ab = np.subtract(a, b)
    bc = np.subtract(b, c)
    
    theta = np.arccos(np.dot(ab, bc) / np.multiply(np.linalg.norm(ab), np.linalg.norm(bc)))     # A.B = |A||B|cos(x) where x is the angle b/w A and B
    theta = 180 - 180 * theta / 3.14    # Convert radians to degrees
    return np.round(theta, 2)

def getBicespsCount():   
    
    mp_drawing = mp.solutions.drawing_utils     # Connecting Keypoints Visuals
    mp_pose = mp.solutions.pose                 # Keypoint detection model
    left_flag = None     # Flag which stores hand position(Either UP or DOWN)
    left_count = 0       # Storage for count of bicep curls
    right_flag = None
    right_count = 0  
    
    username = usernamefortime
    
    pose = mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.5) # Lnadmark detection model instance
    while True:
        try:        
            img_resp = requests.get(url)
            img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
            
            img = cv2.imdecode(img_arr,-1)
            
            small_frame = cv2.resize(img, (0, 0), fx=0.60, fy=0.60)
    
            # BGR to RGB
            image = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)      # Convert BGR frame to RGB
            image.flags.writeable = False
            
            # Make Detections
            results = pose.process(image)                       # Get landmarks of the object in frame from the model
    
            # Back to BGR
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)      # Convert RGB back to BGR
    
            try:
                # Extract Landmarks
                landmarks = results.pose_landmarks.landmark
                left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER]
                left_elbow = landmarks[mp_pose.PoseLandmark.LEFT_ELBOW]
                left_wrist = landmarks[mp_pose.PoseLandmark.LEFT_WRIST]
                right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER]
                right_elbow = landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW]
                right_wrist = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST]
    
                # Calculate angle
                left_angle = calc_angle(left_shoulder, left_elbow, left_wrist)      #  Get angle 
                right_angle = calc_angle(right_shoulder, right_elbow, right_wrist)
    
                # Visualize angle
                cv2.putText(image,\
                        str(left_angle), \
                            tuple(np.multiply([left_elbow.x, left_elbow.y], [640,480]).astype(int)),\
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255),2,cv2.LINE_AA)
                cv2.putText(image,\
                        str(right_angle), \
                            tuple(np.multiply([right_elbow.x, right_elbow.y], [640,480]).astype(int)),\
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255),2,cv2.LINE_AA)
            
                # Counter 
                if left_angle > 160:
                    left_flag = 'down'
                if left_angle < 50 and left_flag=='down':
                    left_count += 1
                    left_flag = 'up'
    
                if right_angle > 160:
                    right_flag = 'down'
                if right_angle < 50 and right_flag=='down':
                    right_count += 1
                    right_flag = 'up'
                
            except:
                pass
    
            # Setup Status Box
            cv2.rectangle(image, (0,0), (1024,73), (10,10,10), -1)
            cv2.putText(image, 'Left=' + str(left_count) + '    Right=' + str(right_count),
                              (10,60), cv2.FONT_HERSHEY_SIMPLEX, 2, (255,255,255), 2, cv2.LINE_AA)
            
            sql1 = "UPDATE exercisevount SET bicepleft = %s,bicepright = %s WHERE username = %s;"
            val1 = (left_count,right_count,username)
            cursor.execute(sql1,val1)
            con.commit()
    
            # Render Detections
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
    
            cv2.imshow('MediaPipe feed', image)
    
            k = cv2.waitKey(10) & 0xff  # Esc for quiting the app
            if k==27:
                break
            elif k==ord('r'):       # Reset the counter on pressing 'r' on the Keyboard
                left_count = 0
                right_count = 0

        except:
            break
    cv2.destroyAllWindows()
    
"----------------------------------------   PUSH-UPS   -------------------------------------------------------"
    
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
opname = "output.avi"

def findPosition(image, draw=True):
    
    lmList = []
    if results1.pose_landmarks:
        mp_drawing.draw_landmarks(
           image, results1.pose_landmarks, mp_pose.POSE_CONNECTIONS)
        for id, lm in enumerate(results1.pose_landmarks.landmark):
            h, w, c = image.shape
            cx, cy = int(lm.x * w), int(lm.y * h)
            lmList.append([id, cx, cy])
            #cv2.circle(image, (cx, cy), 5, (255, 0, 0), cv2.FILLED)
    return lmList

def getPushupCount():
    counter=0
    stage = None
    create = None
    username = usernamefortime
    with mp_pose.Pose(min_detection_confidence=0.7,min_tracking_confidence=0.7) as pose:    
        
        while True:
            try:
                img_resp = requests.get(url)
                img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
                
                img = cv2.imdecode(img_arr,-1)
                
                image = cv2.resize(img, (0, 0), fx=0.50, fy=0.50)
            
                if not True:
                  print("Ignoring empty camera frame.")
                  # If loading a video, use 'break' instead of 'continue'.
                  continue
                # Flip the image horizontally for a later selfie-view display, and convert
                # the BGR image to RGB.
                image = cv2.cvtColor(cv2.flip(image, 1), cv2.COLOR_BGR2RGB)
                # To improve performance, optionally mark the image as not writeable to
                # pass by reference.
                global results1
                results1 = pose.process(image)
                # Draw the pose annotation on the image.
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                lmList = findPosition(image, draw=True)
                if len(lmList) != 0:
                  cv2.circle(image, (lmList[12][1], lmList[12][2]), 20, (0, 0, 255), cv2.FILLED)
                  cv2.circle(image, (lmList[11][1], lmList[11][2]), 20, (0, 0, 255), cv2.FILLED)
                  cv2.circle(image, (lmList[12][1], lmList[12][2]), 20, (0, 0, 255), cv2.FILLED)
                  cv2.circle(image, (lmList[11][1], lmList[11][2]), 20, (0, 0, 255), cv2.FILLED)
                  if (lmList[12][2] and lmList[11][2] >= lmList[14][2] and lmList[13][2]):
                    cv2.circle(image, (lmList[12][1], lmList[12][2]), 20, (0, 255, 0), cv2.FILLED)
                    cv2.circle(image, (lmList[11][1], lmList[11][2]), 20, (0, 255, 0), cv2.FILLED)
                    stage = "down"
            
                  if (lmList[12][2] and lmList[11][2] <= lmList[14][2] and lmList[13][2]) and stage == "down":
                    stage = "up"
                    counter += 1
                    counter2 = str(int(counter))
                    print(counter)
                    # os.system("echo '" + counter2 + "' | festival --tts")
                text = "{}:{}".format("Push Ups", counter)
                
                sql1 = "UPDATE exercisevount SET pushups = %s WHERE username = %s;"
                val1 = (counter,username)
                cursor.execute(sql1,val1)
                con.commit()
                
                cv2.putText(image, text, (10, 40), cv2.FONT_HERSHEY_SIMPLEX,
                            1, (255, 0, 0), 2)
                
                cv2.imshow('MediaPipe Pose', image)
                if create is None:
                  fourcc = cv2.VideoWriter_fourcc(*'XVID')
                  create = cv2.VideoWriter(opname, fourcc, 30, (image.shape[1], image.shape[0]), True)
                create.write(image)
                key = cv2.waitKey(10) & 0xFF
                # if the q key was pressed, break from the loop
                if key == ord("q"):
                  break
            
            except:
                break
          # do a bit of cleanup
      
        cv2.destroyAllWindows()        

"----------------------------------------   Planks   ---------------------------------------------------------"

engine = pyttsx3.init("sapi5")
voice = engine.getProperty("voices")
engine.setProperty('voice',voice[0].id)
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

def calculate_angle(a,b,c):
    a = np.array(a) # First
    b = np.array(b) # Mid
    c = np.array(c) # End
    
    radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
    angle = np.abs(radians*180.0/np.pi)
    
    if angle >180.0:
        angle = 360-angle
        
    return angle 

# Plank stage variables

## Setup mediapipe instance
def getPlanksCount():    
    stage = None
    flag = 0
    counter=0
    username = usernamefortime
    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while True:
            try:
                img_resp = requests.get(url)
                img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
                
                img = cv2.imdecode(img_arr,-1)
                
                small_frame = cv2.resize(img, (0, 0), fx=0.50, fy=0.50)
                
                # Recolor image to RGB
                image = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False
              
                # Make detection
                results = pose.process(image)
            
                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                
                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark
                    
                    # Get coordinates
                    shoulder = [landmarks[11].x,landmarks[11].y]
                    elbow = [landmarks[13].x,landmarks[13].y]
                    wrist = [landmarks[15].x,landmarks[15].y]
                    hip = [landmarks[23].x,landmarks[23].y]
                    knee = [landmarks[25].x,landmarks[25].y]
                    
                    # Calculate angle
                    angle1 = calculate_angle(shoulder, elbow, wrist)
                    angle2 = calculate_angle(shoulder, hip, knee)
                    
                    # Visualize angle
                    cv2.putText(image, str(angle1), 
                                   tuple(np.multiply(elbow, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA
                                        )
                    cv2.putText(image, str(angle2), 
                                   tuple(np.multiply(hip, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA
                                        )
                    
                    # Plank pose logic
                    if angle1>80 and angle1<100 and angle2>170 and angle2<190:
                    # if angle1>60 and angle1<80 and angle2>150 and angle2<170:
                        stage = "perfect"   
                    else:
                        stage = "wrong" 
                        
                    if flag == 0 and stage == "perfect" :
                        flag = 0
                        counter+=1
                    elif flag == 0 and stage == "wrong" :
                        # print("wrong")
                        flag = 0
                except:
                    pass
                
                # Render plank pose detector
                # Setup status box
                cv2.rectangle(image, (0,0), (225,73), (245,117,16), -1)
                
        
                
                # Stage data
                cv2.putText(image, 'STAGE', (65,12), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
                
                # print("planks")
                # print(str(counter)+"     "+str(username))
                sql12 = "UPDATE exercisevount SET planks = %s WHERE username = %s;"
                val12 = (counter,username)
                cursor.execute(sql12,val12)
                con.commit()
                
                # cv2.putText(image, stage, 
                #             (60,60), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
                cv2.putText(image,"Count-"+str(counter), 
                            (60,60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
                
                
                # Render detectionsq
                mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                        mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=2), 
                                        mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2) 
                                         )               
                
                cv2.imshow('Mediapipe Feed', image)
        
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break
            except:
                break
        # cap.release()
        cv2.destroyAllWindows()        

"---------------------------------------   Downward facing dog   ---------------------------------------------"

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
engine = pyttsx3.init("sapi5")
voice = engine.getProperty("voices")
engine.setProperty('voice',voice[0].id)

def getDownwardsCount():
    stage = None
    i = 0
    counter=0
    username = usernamefortime
    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while True:
            try:
                img_resp = requests.get(url)
                img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
                
                img = cv2.imdecode(img_arr,-1)
                
                small_frame = cv2.resize(img, (0, 0), fx=0.50, fy=0.50)
                
                # Recolor image to RGB
                image = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False
              
                # Make detection
                results = pose.process(image)
            
                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                
                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark
                    
                     # Get coordinates
                    shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                    elbow = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                    wrist = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
                    hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]
                    knee = landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y
                    ankle = landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].y
                    
                    def calculate_angle(a,b,c):
                        a = np.array(a) # First
                        b = np.array(b) # Mid
                        c = np.array(c) # End
                        
                        radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
                        angle = np.abs(radians*180.0/np.pi)
            
                        if angle >180.0:
                            angle = 360-angle
                
                        return angle 
                    
                    # Calculate angle
                    angle1 = calculate_angle(shoulder, elbow, wrist)
                    angle2 = calculate_angle(knee, hip, shoulder)
                    angle3 = calculate_angle(ankle, knee, hip)
                    # Visualize angle
                    cv2.putText(image, str(angle1), 
                                   tuple(np.multiply(elbow, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA
                                        )
                    cv2.putText(image, str(angle2), 
                                   tuple(np.multiply(hip, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA
                                        )
                    cv2.putText(image, str(angle3), 
                                   tuple(np.multiply(knee, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA
                                        )
                    
                    # pose judging logic
                    if angle1 > 170 and angle2 > 52 and angle2 < 67 and angle3 > 170:
                        stage = "Correct"
                    else:
                        stage="Incorrect"
        
                    if i == 0: 
                        flag = 0
                    elif stage == "Correct" and flag == 0:
                        flag = 0
                        counter+=1
                    elif stage == "Incorrect" and flag == 0:
                        flag = 0
                    i += 1
        
                except:
                    pass
                
                # Render pose status
                # Setup status box
                cv2.rectangle(image, (0,0), (225,73), (245,117,16), -1)
                
                cv2.putText(image, stage, 
                            (15,20), 
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
                
                sql1 = "UPDATE exercisevount SET downdog = %s WHERE username = %s;"
                val1 = (counter,username)
                cursor.execute(sql1,val1)
                con.commit()
                
                cv2.putText(image,"Count-"+str(counter), 
                            (60,60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
                
                
                # Render detections
                mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                        mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=2), 
                                        mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2) 
                                         )               
                
                cv2.imshow('Mediapipe Feed', image)
        
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break
            except:
                break
        # cap.release()
        cv2.destroyAllWindows()        
        
"--------------------------------------------   Shoulder   ---------------------------------------------------"

mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose

def getShoulderCount():
    counter = 0 
    stage = None
    username = usernamefortime
    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while True:
            try:
                img_resp = requests.get(url)
                img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
                
                img = cv2.imdecode(img_arr,-1)
                
                small_frame = cv2.resize(img, (0, 0), fx=0.50, fy=0.50)
                
                # Recolor image to RGB
                image = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False
              
                # Make detection
                results = pose.process(image)
            
                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                
                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark
                    
                    # Get coordinates
                    shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                    elbow = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                    wrist = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
                    
                    # Calculate angle
                    angle = calculate_angle(shoulder, elbow, wrist)
                    
                    # Visualize angle
                    cv2.putText(image, str(angle), 
                                   tuple(np.multiply(elbow, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                    
                    # Curl counter logic
                    # if angle > 160:
                    #     stage = "up"
                    # if angle < 30 and stage =='up':
                    #     stage="down"
                    #     counter +=1
                    #     print(counter)
                    
                    if angle > 160:
                        stage = "up"
                    if angle < 60 and stage =='up':
                        stage="down"
                        counter +=1
                               
                except:
                    pass
                
                # Render curl counter
                # Setup status box
                # cv2.rectangle(image, (0,0), (225,73), (245,117,16), -1)
                cv2.rectangle(image, (0,0), (310,73), (245,117,16), -1)
                
                sql1 = "UPDATE exercisevount SET shoulder = %s WHERE username = %s;"
                val1 = (counter,username)
                cursor.execute(sql1,val1)
                con.commit()
                # # Rep data
                # cv2.putText(image, 'REPS', (15,12), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
                cv2.putText(image, "Count:"+str(counter), 
                            (10,60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255,255,255), 2, cv2.LINE_AA)
                
                # Stage data
                # cv2.putText(image, 'STAGE', (65,12), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
                # cv2.putText(image, stage, 
                #             (60,60), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 2, (255,255,255), 2, cv2.LINE_AA)
                
                
                # Render detections
                mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                        mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=2), 
                                        mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2))               
                
                cv2.imshow('Mediapipe Feed', image)
        
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break
            except:
                break
    
        # cap.release()
        cv2.destroyAllWindows()

"--------------------------------------------   Squarts   ----------------------------------------------------"

def getSquartsCount():    
    counter = 0 
    stage = None
    username = usernamefortime
    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        while True:
            try:
                img_resp = requests.get(url)
                img_arr = np.array(bytearray(img_resp.content),dtype=np.uint8)
                
                img = cv2.imdecode(img_arr,-1)
                
                small_frame = cv2.resize(img, (0, 0), fx=0.50, fy=0.50)
                
                # Recolor image to RGB
                image = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False
              
                # Make detection
                results = pose.process(image)
            
                # Recolor back to BGR
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                
                # Extract landmarks
                try:
                    landmarks = results.pose_landmarks.landmark
                    
                    # Get coordinates
                    shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                    elbow = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                    wrist = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
                    
                    
                    # Get coordinates
                    hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]
                    knee = [landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].x,landmarks[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
                    ankle = [landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
                    
                   
                    
                    # Calculate angle
                    angle = calculate_angle(shoulder, elbow, wrist)
                    
                    angle_knee = calculate_angle(hip, knee, ankle) #Knee joint angle
                    
                    angle_hip = calculate_angle(shoulder, hip, knee)
                    hip_angle = 180-angle_hip
                    knee_angle = 180-angle_knee                           
                        
                    cv2.putText(image, str(angle_knee), 
                                   tuple(np.multiply(knee, [640, 480]).astype(int)), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (79, 121, 66), 2, cv2.LINE_AA
                                        )
                    
                    # Curl counter logic
                    if angle_knee > 169:
                        stage = "UP"
                    if angle_knee <= 90 and stage =='UP':
                        stage="DOWN"
                        counter +=1
                except:
                    pass
                
                # Render squat counter
                # Setup status box
                cv2.rectangle(image, (0,0), (310,73), (245,117,16), -1)
                
                sql1 = "UPDATE exercisevount SET squarts = %s WHERE username = %s;"
                val1 = (counter,username)
                cursor.execute(sql1,val1)
                con.commit()
                
                # Rep data
                # cv2.putText(image, 'REPS', (15,12), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
                cv2.putText(image, "Count:"+str(counter), 
                            (10,60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (255,255,255), 2, cv2.LINE_AA)
                
                # # Stage data
                # cv2.putText(image, 'STAGE', (65,12), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1, cv2.LINE_AA)
                # cv2.putText(image, stage, 
                #             (60,60), 
                #             cv2.FONT_HERSHEY_SIMPLEX, 2, (255,255,255), 2, cv2.LINE_AA)
                
                
                # Render detections
                mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS,
                                        mp_drawing.DrawingSpec(color=(245,117,66), thickness=2, circle_radius=2), 
                                        mp_drawing.DrawingSpec(color=(245,66,230), thickness=2, circle_radius=2))               
                
                cv2.imshow('Mediapipe Feed', image)
        
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break
            except:
                break
    
        cv2.destroyAllWindows()

"-------------------------------------------------------------------------------------------------------------"

@app.route('/userRegister', methods=['GET', 'POST'])
def userRegister():
    if request.method == 'POST':
        print("GET")        

        Email = request.form.get("email")
        Username = request.form.get("username")        
        Password = request.form.get("textpassword")
        Retype_password = request.form.get("textpassword1")        
        print("INPUTS")        
        print("Username",Username)
        
        cursor.execute('SELECT * FROM register WHERE Username = %s', (Username))
        count = cursor.rowcount
        if count == 0:
            sql1 = "INSERT INTO register(Username, Email,Mobile, Password) VALUES (%s, %s, %s, %s);"
            val1 = (Username, Email,Password, Retype_password)
            cursor.execute(sql1,val1)
            con.commit()
            
            sql11 = "INSERT INTO exercisevount(Username) VALUES (%s);"
            val11 = (Username)
            cursor.execute(sql11,val11)
            con.commit()
            return "success"
        else:
            return "Fail"
                       
    
@app.route('/userLogin', methods=['GET', 'POST'])
def userLogin():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password")       
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM register WHERE Username = %s AND Password = %s', (username, passw))
        count = cursor.rowcount
        if count == 1:
            return "success"
        else:
            return "Fail"
        
        
@app.route('/forgot', methods=['GET', 'POST'])
def forgot():
    print("GET") 
    if request.method == 'POST':
        print("POST")        

        username = request.form.get("email")
        email = request.form.get("username") 
        mobile = request.form.get("mobile")
        password= request.form.get("password1")      
        
        cursor.execute('SELECT * FROM register WHERE Username = %s', (username))
        count = cursor.rowcount
        if count == 1:
            sql1 = "UPDATE register SET Email = %s,Mobile = %s,Password = %s WHERE Username = %s;"
            val1 = (email,mobile,password,username)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"
        else:
            return "Fail"
        
@app.route('/getExciseCount', methods=['GET', 'POST'])
def getExciseCount():
    if request.method == 'POST':          
        
        username = request.form.get("username")
        exercise = request.form.get("exercise")    
        
        print("Selected exercise : "+exercise)
        
        global usernamefortime   
        usernamefortime = username 
        
        if exercise == "biceps":
            start_time = threading.Timer(int(3),getBicespsCount)
            start_time.start()  
        elif exercise == "planks":
            start_time = threading.Timer(int(3),getPlanksCount)
            start_time.start()  
        elif exercise == "downward":
            start_time = threading.Timer(int(3),getDownwardsCount)
            start_time.start()
        elif exercise == "shoulder":
            start_time = threading.Timer(int(3),getShoulderCount)
            start_time.start()  
        elif exercise == "squarts":
            start_time = threading.Timer(int(3),getSquartsCount)
            start_time.start()
        else:            
            start_time = threading.Timer(int(3),getPushupCount)
            start_time.start()
            
        return "success"
    
@app.route('/getResult', methods=['GET', 'POST'])
def getResult():
    if request.method == 'POST':  
        
        username = request.form.get("username")
        
        cursor.execute('SELECT * FROM exercisevount WHERE username=%s',(username))
        row = cursor.fetchone()
        
        jsonObj = json.dumps(row)
        # print(jsonObj)        
        
        return jsonObj



    
if __name__ == "__main__":
    app.run("0.0.0.0")
