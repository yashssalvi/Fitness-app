/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - fitness
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`fitness` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `fitness`;

/*Table structure for table `exercisevount` */

DROP TABLE IF EXISTS `exercisevount`;

CREATE TABLE `exercisevount` (
  `username` varchar(255) default NULL,
  `bicepleft` int(255) default '0',
  `bicepright` int(255) default '0',
  `pushups` int(255) default '0',
  `planks` int(255) default '0',
  `downdog` int(255) default '0',
  `shoulder` int(255) default '0',
  `squarts` int(255) default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `exercisevount` */

insert  into `exercisevount`(`username`,`bicepleft`,`bicepright`,`pushups`,`planks`,`downdog`,`shoulder`,`squarts`) values ('a',3,3,0,0,0,9,0),('b',5,4,5,0,0,0,0),('c',0,0,0,0,0,0,0);

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `Id` int(255) NOT NULL auto_increment,
  `Username` varchar(255) default NULL,
  `Email` varchar(255) default NULL,
  `Mobile` varchar(255) default NULL,
  `Password` varchar(255) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`Id`,`Username`,`Email`,`Mobile`,`Password`) values (1,'a','yashsalvi199@gmail.com','1234567890','a'),(2,'b','yashsalvi1999@gmail.comdh','3164578908','b'),(3,'c','yas@4gmail.com','1235567890','c');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
