package com.baecon.spike.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.baecon.spike.MainActivity;
import com.baecon.spike.R;
import com.baecon.spike.UrlLinks;
import com.baecon.spike.databinding.FragmentHomeBinding;
import com.baecon.spike.jSOnClassforData;
import com.baecon.spike.login;
import com.baecon.spike.testing;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    CardView biceps,pushups,planks,downward,shoulder,squarts;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = FragmentHomeBinding.inflate(inflater, container, false).getRoot();

        biceps=root.findViewById(R.id.biceps);
        planks=root.findViewById(R.id.planks);
        pushups=root.findViewById(R.id.pushups);
        downward=root.findViewById(R.id.downward);
        shoulder=root.findViewById(R.id.shoulder);
        squarts=root.findViewById(R.id.squarts);

        biceps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "biceps"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        planks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "planks"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        pushups.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "pushups"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        downward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "downward"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        shoulder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "shoulder"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        squarts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.getExciseCount;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("username",login.session));
                nameValuePairs.add(new BasicNameValuePair("exercise", "squarts"));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {

                    Intent launchIntent = getActivity().getPackageManager().getLaunchIntentForPackage("com.pas.webcam");
                    if (launchIntent != null) {
                        startActivity(launchIntent);
                    }
                    else {
                        Toast.makeText(getActivity(), "App not installed", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    Toast.makeText(getActivity(), "Server not started", Toast.LENGTH_SHORT).show();

                }

            }
        });

        return root;
    }
}