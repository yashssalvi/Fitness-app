package com.baecon.spike;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class forget extends AppCompatActivity {
    TextView reg;
    EditText ed1,ed2,ed3,ed4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpwd);

        reg = findViewById(R.id.login);
        ed1 = findViewById(R.id.text);
        ed2 = findViewById(R.id.email);
        ed3 = findViewById(R.id.Password);
        ed4 = findViewById(R.id.NewPassword);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                if (username.equals("") || password.equals("")) {
                    Toast.makeText(forget.this, "Please fill details.", Toast.LENGTH_SHORT).show();
                } else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.pyforget;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);

                    nameValuePairs.add(new BasicNameValuePair("email", username));
                    nameValuePairs.add(new BasicNameValuePair("username", email));
                    nameValuePairs.add(new BasicNameValuePair("mobile", mobile));
                    nameValuePairs.add(new BasicNameValuePair("password1", password));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {

                        Toast.makeText(forget.this, "Successfully", Toast.LENGTH_SHORT).show();
                        Intent io = new Intent(forget.this, login.class);

                        startActivity(io);
                        finish();

                    } else {

                        Toast.makeText(forget.this, "change password succesfully", Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });


    }
}