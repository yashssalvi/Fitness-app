package com.baecon.spike.ui.slideshow;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.baecon.spike.databinding.FragmentSlideshowBinding;
import com.baecon.spike.login;

public class SlideshowFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = FragmentSlideshowBinding.inflate(inflater, container, false).getRoot();

        Intent loginActivity = new Intent(getContext(), login.class);
        startActivity(loginActivity);

        return root;
    }
}