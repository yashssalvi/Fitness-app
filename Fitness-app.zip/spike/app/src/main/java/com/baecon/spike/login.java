package com.baecon.spike;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class login extends AppCompatActivity {
    ImageButton ig;
    TextView txlog,Forgot;
    EditText ed1,ed2;
    public static String session="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txlog = findViewById(R.id.login);
        ed1 = findViewById(R.id.text);
        ed2 = findViewById(R.id.Password);
        Forgot = findViewById(R.id.Forgot);
        ig = findViewById(R.id.btRegister);
        ig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this,register.class));

            }
        });

        Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this,forget.class));

            }
        });

        txlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String password = ed2.getText().toString();

                if(username.equals("") || password.equals("")){
                    Toast.makeText(login.this, "Please fill details.", Toast.LENGTH_SHORT).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.pylogin;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                    nameValuePairs.add(new BasicNameValuePair("username", username));
                    nameValuePairs.add(new BasicNameValuePair("password", password));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {

                        session=username;

                        Toast.makeText(login.this, "Successfully", Toast.LENGTH_SHORT).show();
                        Intent io = new Intent(login.this, MainActivity.class);

                        startActivity(io);
                        finish();

                    } else {

                        Toast.makeText(login.this, "Wrong username or password", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });

    }
}