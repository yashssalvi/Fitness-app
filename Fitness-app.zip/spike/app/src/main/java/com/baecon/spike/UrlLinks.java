package com.baecon.spike;

public class UrlLinks {
    public static String urlserver="http://192.168.0.100:8080";

    public static String urlserverpython="http://192.168.0.100:5000/";
    public static String registrationurl=urlserver+"registerUser";

    public static String pyregister=urlserverpython+"userRegister";
    public static String pylogin=urlserverpython+"userLogin";
    public static String pyforget=urlserverpython+"forgot";

    public static String getExciseCount=urlserverpython+"getExciseCount";
    public static String getResult=urlserverpython+"getResult";


}
