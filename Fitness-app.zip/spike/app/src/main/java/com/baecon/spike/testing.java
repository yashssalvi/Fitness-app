package com.baecon.spike;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class testing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
    }
}