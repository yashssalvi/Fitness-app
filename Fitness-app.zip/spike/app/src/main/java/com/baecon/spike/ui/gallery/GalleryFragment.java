package com.baecon.spike.ui.gallery;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.baecon.spike.R;
import com.baecon.spike.UrlLinks;
import com.baecon.spike.databinding.FragmentGalleryBinding;
import com.baecon.spike.jSOnClassforData;
import com.baecon.spike.login;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class GalleryFragment extends Fragment {

    TextView tx1,tx2,tx3,tx4,tx5,tx6,tx7;
    TextView txx1,txx2,txx3,txx4,txx5,txx6;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = FragmentGalleryBinding.inflate(inflater, container, false).getRoot();

        tx1 = root.findViewById(R.id.bicepstxt1);
        tx2 = root.findViewById(R.id.bicepstxt2);
        tx3 = root.findViewById(R.id.plankstxt);
        tx4 = root.findViewById(R.id.pushupstxt);
        tx5 = root.findViewById(R.id.downwardtxt);
        tx6 = root.findViewById(R.id.shouldertxt);
        tx7 = root.findViewById(R.id.squartstxt);

        txx1 = root.findViewById(R.id.bicepscal);
        txx2 = root.findViewById(R.id.plankscal);
        txx3 = root.findViewById(R.id.pushupscal);
        txx4 = root.findViewById(R.id.downwardcal);
        txx5 = root.findViewById(R.id.shouldercal);
        txx6 = root.findViewById(R.id.squartscal);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String url = UrlLinks.getResult;

        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

        nameValuePairs.add(new BasicNameValuePair("username", login.session));

        String result = null;
        try {
            result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            JSONArray jsonArray = new JSONArray(result);

            String l1 = String.valueOf(jsonArray.getString(1));
            String r1 = String.valueOf(jsonArray.getString(2));
            String p1 = String.valueOf(jsonArray.getString(3));
            String p2 = String.valueOf(jsonArray.getString(4));
            String d1 = String.valueOf(jsonArray.getString(5));
            String s1 = String.valueOf(jsonArray.getString(6));
            String s2 = String.valueOf(jsonArray.getString(7));

            tx1.setText(l1);
            tx2.setText(r1);
            tx3.setText(p1);
            tx4.setText(p2);
            tx5.setText(d1);
            tx6.setText(s1);
            tx7.setText(s2);

            double result1 = (Integer.parseInt(l1) + Integer.parseInt(r1)) * 0.2;
            txx1.setText(String.format("%.4f Cal", result1));

            double result2 = Integer.parseInt(p1) * 0.369;
            txx2.setText(String.format("%.4f Cal", result2));

            double result3 = Integer.parseInt(p2) * 0.2596;
            txx3.setText(String.format("%.4f Cal", result3));

            double result4 = Integer.parseInt(d1) * 0.1569;
            txx4.setText(String.format("%.4f Cal", result4));

            double result5 = Integer.parseInt(s1) * 0.025;
            txx5.setText(String.format("%.4f Cal", result5));

            double result6 = Integer.parseInt(s2) * 0.69;
            txx6.setText(String.format("%.4f Cal", result6));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return root;
    }
}